// ZSmart Ticket Copilot — service worker

// Clicking the toolbar icon opens the side panel.
chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch(console.error);

// Right-click on highlighted text -> "Suggest resolution for selection".
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "zsmart-copilot-selection",
    title: "Suggest resolution for selected text",
    contexts: ["selection"],
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== "zsmart-copilot-selection" || !tab) return;
  await chrome.sidePanel.open({ tabId: tab.id });
  // Give the panel a moment to load, then tell it to run a capture.
  setTimeout(() => {
    chrome.runtime
      .sendMessage({ type: "PANEL_TRIGGER_CAPTURE", tabId: tab.id })
      .catch(() => {});
  }, 400);
});
